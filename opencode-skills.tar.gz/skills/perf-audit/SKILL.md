---
name: perf-audit
description: Performance audit for Next.js apps and Supabase — bundle size,
  Core Web Vitals, React rendering, and slow DB queries. Load when the user
  says "slow", "performance", "optimize", or "bundle".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Performance Audit

## Next.js Bundle Analysis

Install and run the analyzer:

```bash
npm install --save-dev @next/bundle-analyzer
```

```typescript
// next.config.ts
import bundleAnalyzer from '@next/bundle-analyzer'

const withBundleAnalyzer = bundleAnalyzer({
  enabled: process.env.ANALYZE === 'true',
})

export default withBundleAnalyzer({ /* your config */ })
```

```bash
ANALYZE=true npm run build
```

**What to look for:**
- Any single chunk > 200 KB (uncompressed) — find what's importing it
- Packages loaded client-side that should be server-only
- Duplicate packages at different versions (check with `npm ls <package>`)

## Core Web Vitals Targets

| Metric | Good | Needs Work |
|---|---|---|
| LCP (Largest Contentful Paint) | < 2.5s | > 4s |
| INP (Interaction to Next Paint) | < 200ms | > 500ms |
| CLS (Cumulative Layout Shift) | < 0.1 | > 0.25 |

Measure with: `npx lighthouse http://localhost:3000 --view`

## React Rendering

### When to memoize

```typescript
// memo — skip re-render if props haven't changed (expensive components only)
const ProjectCard = memo(function ProjectCard({ project }: Props) { ... })

// useMemo — expensive derived value
const filtered = useMemo(
  () => projects.filter(p => p.status === activeFilter),
  [projects, activeFilter]
)

// useCallback — stable function ref for child component or effect dep
const handleDelete = useCallback((id: string) => {
  setProjects(prev => prev.filter(p => p.id !== id))
}, [])
```

**Rule of thumb**: profile before memoizing. Memoization has a cost too.

### Find re-render culprits

Add React DevTools Profiler to dev build. Look for:
- Components that render > 10× per interaction
- Long render times (> 16ms blocks 60fps)
- Context re-renders cascading through large trees — split context or use Zustand

## Image Optimization

Always use `next/image` — never a bare `<img>`:

```typescript
import Image from 'next/image'

<Image
  src={project.thumbnailUrl}
  alt={project.name}
  width={400}
  height={300}
  placeholder="blur"        // eliminates CLS
  blurDataURL={blurHash}
/>
```

- Set `sizes` prop for responsive images to avoid downloading oversized assets
- Use `priority` on above-the-fold images to improve LCP

## Supabase Query Performance

Find slow queries — run in Supabase SQL editor:

```sql
-- Queries with no index (sequential scans on large tables)
SELECT
  schemaname,
  tablename,
  seq_scan,
  idx_scan,
  n_live_tup
FROM pg_stat_user_tables
WHERE seq_scan > idx_scan
  AND n_live_tup > 1000
ORDER BY seq_scan DESC;
```

Analyze a specific slow query:

```sql
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT * FROM projects WHERE user_id = 'some-uuid' ORDER BY created_at DESC;
```

**Signs of trouble:**
- `Seq Scan` on a table with many rows → add an index
- `Rows Removed by Filter: <large number>` → partial index or better WHERE clause
- High `Planning Time` → statistics stale, run `ANALYZE projects;`
