---
name: debug-session
description: Structured debugging process for errors, unexpected behavior, or
  failing tests. Use when the user shares an error, says "it's broken", "help
  debug", or "why isn't this working".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Debug Session

When given an error or unexpected behavior:

## Step 1 — Understand the Error

1. Read the full error message and stack trace — do not skim
2. Identify the *exact* file and line number
3. Classify the error type:
   - **Syntax/type**: caught at compile/parse time
   - **Runtime**: occurs during execution
   - **Logic**: runs without error but wrong output
   - **Environment**: works locally, fails in prod (env vars, permissions, ports)

## Step 2 — Gather Context

Ask for (or look for) these if not provided:
- Full error output including stack trace
- The code at the failing line and 10 lines around it
- What was the last change made before it broke?
- Does it fail consistently or intermittently?
- Which environment: local dev / staging / production?

## Step 3 — Hypothesize

Generate 2–3 ranked hypotheses:
```
1. [Most likely] — reason it fits the symptoms
2. [Possible] — alternative explanation
3. [Less likely but check] — edge case
```

## Step 4 — Verify

- For each hypothesis, suggest a specific check or minimal reproduction
- Prefer `console.log` / `print` over complex debugging setups for quick checks
- For Supabase errors: check the Supabase dashboard logs first

## Step 5 — Fix

- Apply the minimal fix that addresses the root cause
- Explain *why* the bug occurred, not just what changed
- Suggest a test to prevent regression

## Common Patterns

| Symptom | Likely cause |
|---|---|
| `undefined` in JS where object expected | Missing `await`, or optional chain needed |
| 401 on Supabase query | RLS blocking access, check `auth.uid()` in policy |
| CORS error | Missing `Access-Control-Allow-Origin` header in Edge Function |
| Port already in use | Previous process still running — `lsof -i :3000` |
| Docker container exits immediately | App crash — `docker logs <container>` |
| Python `ModuleNotFoundError` | Wrong virtualenv activated or missing `pip install -e .` |
| Agent tool call returns error | Check tool schema matches what the model produced — log raw output |
| `ValidationError` on agent result | LLM returned malformed JSON — add retry or lower temperature |
| `ContextLengthExceeded` | Prompt too long — truncate injected files, summarize history |
| MCP tool call times out | MCP server crashed or slow — check server logs, restart server |
| Agent loops indefinitely | Missing `maxSteps` limit or tool always returns actionable result |
