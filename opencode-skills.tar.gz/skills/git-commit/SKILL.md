---
name: git-commit
description: Writes conventional commit messages from staged changes and commits
  them. Use when the user asks to commit, write a commit, stage changes, or
  says "commit this".
---

> **Model**: `opencode/big-pickle`

# Git Commit Writer

When asked to write and create a commit:

1. Run `git diff --staged` to inspect staged changes
2. If nothing is staged, run `git status` and ask the user which files to stage
3. Stage the files the user confirms: `git add <file1> <file2> ...`
4. Identify the primary change type:
   - `feat`: new feature visible to users
   - `fix`: bug fix
   - `refactor`: restructure without behavior change
   - `perf`: performance improvement
   - `test`: add or fix tests
   - `docs`: documentation only
   - `chore`: build, tooling, deps, CI
   - `style`: formatting, no logic change
5. Identify the scope from changed file paths (e.g., `auth`, `api`, `ui`, `db`, `agent`)
6. Write subject: `type(scope): imperative description` — max 72 chars
7. If the change is non-trivial, add a body explaining *why*, not *what*
8. Add `BREAKING CHANGE:` footer if any public API changes
9. Run the commit:

```bash
git commit -m "$(cat <<'EOF'
type(scope): short description

Optional body explaining why, not what. Wrapped at 72 chars.
EOF
)"
```

## Rules
- Subject line: imperative mood, lowercase, no period
- Body: wrapped at 72 chars, blank line between subject and body
- If multiple logical concerns are staged, suggest splitting commits
- Never invent changes not present in the diff
- Never use `--no-verify` unless the user explicitly asks
