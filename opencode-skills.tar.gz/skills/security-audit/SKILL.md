---
name: security-audit
description: Security audit focused on web apps and APIs — OWASP Top 10,
  Supabase RLS, auth flows, secrets, and injection attacks. Use when the user
  says "security", "audit", "pentest", or "check for vulnerabilities".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Security Audit

## OWASP Top 10 Checklist

### A01 — Broken Access Control
- [ ] Every Supabase table has RLS enabled with explicit policies
- [ ] Service role key never in client-side code or environment files committed to git
- [ ] API routes check `auth.uid()` — no user can access another user's data
- [ ] Admin routes behind role checks, not just hidden URLs

### A02 — Cryptographic Failures
- [ ] All secrets in environment variables, never hardcoded
- [ ] `.env` and `.env.local` in `.gitignore`
- [ ] Passwords hashed (use Supabase Auth — never roll your own)
- [ ] Sensitive data not logged

### A03 — Injection
- [ ] All database queries use parameterized queries / Supabase client (not raw SQL with string concat)
- [ ] User input sanitized before rendering in HTML (React escapes by default — avoid `dangerouslySetInnerHTML`)
- [ ] Shell commands never built from user input

### A06 — Vulnerable & Outdated Components
- [ ] Run `npm audit` — fix critical and high findings before shipping

```bash
npm audit --audit-level=high
npm audit fix           # auto-fix non-breaking
npm audit fix --force   # only if you review the diff
```

- [ ] Run `pip audit` for Python projects:

```bash
pip install pip-audit
pip-audit                       # scan current env
pip-audit -r requirements.txt  # scan requirements file
```

- [ ] Pin dependency versions in `package.json` and `pyproject.toml` — avoid `*` or `latest`

### A07 — Auth Failures
- [ ] Session tokens not stored in localStorage (use httpOnly cookies)
- [ ] Password reset tokens expire after single use
- [ ] Logout invalidates server-side session

### A09 — Security Logging
- [ ] Auth failures logged with IP + timestamp (not passwords)
- [ ] Unexpected 5xx errors alerted

## Supabase-Specific Checks

```sql
-- Find tables with RLS disabled
SELECT tablename FROM pg_tables
WHERE schemaname = 'public'
AND tablename NOT IN (
  SELECT DISTINCT tablename FROM pg_policies
);
```

## Output Format

For each finding:
- **Severity**: Critical / High / Medium / Low
- **Location**: File, line, or table name
- **Issue**: What's wrong
- **Impact**: What an attacker can do
- **Fix**: Concrete code change
