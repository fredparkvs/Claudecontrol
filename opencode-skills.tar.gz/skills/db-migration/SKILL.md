---
name: db-migration
description: Write safe Supabase/Postgres migrations — additive changes, rollback
  scripts, index strategy, and zero-downtime patterns. Load when the user needs
  to add tables, columns, indexes, or change the schema.
---

> **Model**: `opencode/claude-sonnet-4-6`

# Database Migration Patterns

## Golden Rules

1. **Never drop columns or tables** in the same migration that removes code depending on them — two-step deploy
2. **Always additive first**: add nullable column → deploy code → backfill → add NOT NULL constraint
3. **Every migration file is immutable** once applied to production
4. **Test on a copy** before running on production Supabase

## Migration File Structure (Supabase)

```sql
-- supabase/migrations/20260507_add_projects.sql

-- UP
CREATE TABLE IF NOT EXISTS public.projects (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name        text NOT NULL,
  status      text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- RLS (never forget this)
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own projects"
  ON public.projects
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Indexes
CREATE INDEX idx_projects_user_id ON public.projects(user_id);
CREATE INDEX idx_projects_status ON public.projects(status) WHERE status = 'active';

-- Updated_at trigger
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER projects_updated_at
  BEFORE UPDATE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
```

## Zero-Downtime Column Add

```sql
-- Step 1 (deploy alone): add nullable
ALTER TABLE projects ADD COLUMN description text;

-- Step 2 (separate migration): backfill
UPDATE projects SET description = '' WHERE description IS NULL;

-- Step 3 (separate migration): add constraint
ALTER TABLE projects ALTER COLUMN description SET NOT NULL;
```

## Index Strategy

- Index every foreign key column
- Index columns used in `WHERE`, `ORDER BY`, `JOIN ON`
- Use partial indexes for status/soft-delete patterns: `WHERE deleted_at IS NULL`
- Check index usage: `SELECT * FROM pg_stat_user_indexes WHERE idx_scan = 0`

## Applying Migrations

```bash
supabase db push                    # local dev
supabase db push --linked           # production (linked project)
supabase migration list             # check applied migrations
```
