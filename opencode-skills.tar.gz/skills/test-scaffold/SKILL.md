---
name: test-scaffold
description: Generates test files for source code. Use when the user asks to
  write tests, add coverage, or says "test this". Detects the test framework
  and matches existing conventions.
---

> **Model**: `opencode/big-pickle`

# Test Scaffolding

When asked to write tests:

1. Detect the testing framework:
   - Check `package.json` for `jest`, `vitest`, `@testing-library`
   - Check for `pytest`, `unittest` in Python projects
   - Look at existing test files to match patterns exactly

2. Read the source file fully before writing any tests

3. Write tests covering:
   - **Happy path**: expected inputs produce expected outputs
   - **Edge cases**: null, undefined, empty string, empty array, 0, negative
   - **Error cases**: invalid inputs, thrown exceptions, rejected promises
   - **Integration**: for API routes, test the full request/response cycle

## Python (pytest)

```python
import pytest
from your_package.core import process_item

def test_process_item_happy_path():
    result = process_item({"id": 1, "name": "test"})
    assert result.success is True

def test_process_item_missing_name():
    with pytest.raises(ValueError, match="name is required"):
        process_item({"id": 1})

@pytest.mark.asyncio
async def test_async_operation():
    result = await async_fetch(url="https://example.com")
    assert result.status == 200
```

## TypeScript/Next.js (vitest)

```typescript
import { describe, it, expect, vi } from 'vitest'
import { processItem } from '../lib/process'

describe('processItem', () => {
  it('returns processed result for valid input', () => {
    const result = processItem({ id: 1, name: 'test' })
    expect(result.success).toBe(true)
  })

  it('throws for missing name', () => {
    expect(() => processItem({ id: 1 })).toThrow('name is required')
  })
})
```

## Supabase Edge Function Tests

```typescript
// test with Deno test runner
Deno.test("returns 200 for valid payload", async () => {
  const req = new Request("http://localhost", {
    method: "POST",
    body: JSON.stringify({ event: "test" }),
  })
  const res = await handler(req)
  assertEquals(res.status, 200)
})
```

## Rules

- One test file per source file, same directory or `tests/` mirror
- Test names: "should [behavior] when [condition]"
- Mock external APIs, databases, file system — tests must run offline
- Never test implementation details — test behavior from the outside
