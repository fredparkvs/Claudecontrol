---
name: plan-write
description: Write a detailed implementation plan before starting to code.
  Use when asked to "plan this", "what's the approach", or before any
  non-trivial feature implementation. Produces a written plan file.
---

> **Model**: `opencode/gpt-5`

# Implementation Planner

When asked to plan a feature or task:

1. **Understand the goal** — restate it in one sentence to confirm understanding
2. **Explore the codebase** — read relevant existing files before proposing anything
3. **Identify dependencies** — what needs to exist before this can be built

## Plan Structure

Write the plan to `.opencode/plans/<feature-name>.md`:

```markdown
# Plan: <Feature Name>
Date: <today>
Status: Draft

## Goal
One sentence: what does this achieve for the user?

## Context
- Relevant existing files: [list with brief purpose]
- Dependencies: [packages, services, migrations needed first]
- Constraints: [performance, auth, free tier limits, etc.]

## Approach
High-level description of the chosen approach and why.
Note any alternatives considered and why rejected.

## Steps
- [ ] Step 1 — specific, actionable, one concern each
- [ ] Step 2
- [ ] Step 3 (depends on Step 2)
...

## Files to Create/Modify
| File | Change |
|---|---|
| `src/feature/component.tsx` | Create — new UI component |
| `supabase/migrations/xxx.sql` | Create — new table |
| `app/api/feature/route.ts` | Modify — add new endpoint |

## Testing Plan
How to verify this works:
- Manual test: [specific steps]
- Automated test: [what to write]

## Open Questions
- [ ] Question 1 — who to ask / how to resolve
```

## Rules

- Never start coding from this skill — planning only
- Ask clarifying questions before writing the plan if scope is unclear
- Plans should be specific enough that a different agent could execute them without the original context
- After writing the plan, ask user to review before proceeding to implementation
