---
name: readme-gen
description: Generates README.md from project structure. Use when the user
  asks to write a README, document the project, or says "generate docs".
---

> **Model**: `opencode/big-pickle`

# README Generator

When asked to generate a README:

1. Scan project root for:
   - `package.json`, `pyproject.toml`, `Cargo.toml` (language/framework)
   - `docker-compose.yml`, `Dockerfile`
   - `.github/workflows/`, `.env.example`
   - Existing `README.md` (update rather than replace if present)

2. Read the main entrypoint to understand what the project does

3. Generate a README with only the relevant sections:

```markdown
# Project Name

One-paragraph description of what it does and who it's for.

## Getting Started

### Prerequisites
[Runtime requirements from actual project files]

### Installation
[Based on actual package manager and setup scripts]

### Running
[Based on scripts in package.json, Makefile, or pyproject.toml]

## Environment Variables
[Only if .env.example exists — list each var with description]

## Tech Stack
[Frameworks and major deps from package files only]

## Project Structure
[Top-level dirs with one-line descriptions]
```

## Rules
- Only include sections that apply — no boilerplate sections for missing things
- All commands based on actual project files, never guessed
- Don't include obvious default sections like "Contributing" unless there's a CONTRIBUTING.md to reference
- If something is unclear, leave a `<!-- TODO: confirm -->` comment
