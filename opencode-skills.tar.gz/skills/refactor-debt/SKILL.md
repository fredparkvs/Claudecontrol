---
name: refactor-debt
description: Identify and fix technical debt — duplicate code, complex functions,
  bad naming, dead code, missing abstractions. Use when user says "refactor",
  "clean up", "tech debt", or "this is a mess".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Refactor & Debt Reduction

When asked to refactor:

1. Read the target files completely — never refactor from partial context
2. List all issues found before making any changes
3. Ask user to confirm the list before proceeding (breaking changes only)
4. Make changes incrementally, not all at once

## What to Look For

### Complexity
- Functions > 30 lines → extract sub-functions
- Nesting > 3 levels → invert conditions, use early returns
- Switch/if chains > 5 cases → use a map/lookup table

### Duplication
- Same logic in 2+ places → extract to shared utility
- Copy-pasted components with slight variations → parameterize

### Naming
- Single-letter variables outside loops → rename to intent
- `data`, `result`, `info` as variable names → make specific
- Boolean names that don't read as questions → rename `is*`, `has*`, `can*`

### Dead Code
- Unused imports, variables, functions → delete
- Commented-out code > 1 week old → delete
- Feature flags that are always true → simplify

## Refactor Output Format

1. **Issue List** — bullet list of all problems found
2. **Priority** — which to fix now vs later
3. **Changed files** — apply changes one file at a time
4. **Verification** — show before/after for non-obvious changes

## Rules
- Never change behavior while refactoring (tests should still pass)
- If no tests exist, note which behaviors need manual verification
- Prefer many small changes over one large rewrite
