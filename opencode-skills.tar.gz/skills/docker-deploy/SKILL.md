---
name: docker-deploy
description: Docker containerization and deployment to VPS (Hetzner) or cloud.
  Dockerfile best practices, docker-compose, and production deployment patterns.
  Load when deploying apps or writing Dockerfiles.
---

> **Model**: `opencode/gpt-5`

# Docker & Deployment Patterns

## Dockerfile — Multi-Stage (Next.js)

```dockerfile
FROM node:20-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/public ./public
EXPOSE 3000
CMD ["node", "server.js"]
```

## Dockerfile — Python (Typer CLI / FastAPI)

```dockerfile
FROM python:3.12-slim AS base
WORKDIR /app
RUN pip install uv

FROM base AS builder
COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev

FROM base AS runner
COPY --from=builder /app/.venv ./.venv
COPY src/ ./src/
ENV PATH="/app/.venv/bin:$PATH"
ENTRYPOINT ["your-cli"]
```

## docker-compose (dev stack)

```yaml
services:
  app:
    build: .
    ports: ["3000:3000"]
    env_file: .env.local
    depends_on: [db]
    volumes:
      - .:/app          # hot reload in dev
      - /app/node_modules

  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: myapp
      POSTGRES_PASSWORD: localpass
    ports: ["5432:5432"]
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
```

## Hetzner VPS Deployment Checklist

1. `docker buildx build --platform linux/amd64 -t registry/app:tag .`
2. Push to registry: `docker push registry/app:tag`
3. On server: `docker compose pull && docker compose up -d`
4. Health check: `docker ps` — all containers show `Up`
5. Logs: `docker compose logs -f app`

## Production Hardening

- Never run containers as root: `USER node` or `USER app` in Dockerfile
- Set memory limits in compose: `mem_limit: 512m`
- Use `.dockerignore` — exclude `node_modules`, `.env`, `.git`, `*.log`
- Pin base image versions: `node:20.14-alpine` not `node:alpine`
