---
name: nextjs-patterns
description: Next.js 14+ App Router patterns — Server Components, layouts,
  data fetching, routing, and performance. Load when building Next.js apps,
  adding routes, or the user says "nextjs" or "app router".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Next.js App Router Patterns

## Component Model

| Component type | When to use |
|---|---|
| Server Component (default) | Data fetching, DB queries, no interactivity |
| Client Component (`"use client"`) | useState, useEffect, event handlers, browser APIs |

Push `"use client"` as far down the tree as possible — keep parents as Server Components.

## Data Fetching

```typescript
// app/projects/page.tsx — Server Component, no useEffect needed
export default async function ProjectsPage() {
  const supabase = createClient()
  const { data, error } = await supabase.from('projects').select('*')
  if (error) throw error
  return <ProjectList projects={data} />
}
```

- Use `cache: 'no-store'` on fetches you never want cached
- Use `revalidate` for ISR: `export const revalidate = 60`
- Parallel data fetching: `Promise.all([fetch1, fetch2])` in server components

## Route Handlers

```typescript
// app/api/webhooks/route.ts
export async function POST(request: Request) {
  const body = await request.json()
  // validate, process
  return Response.json({ ok: true })
}
```

## Loading & Error States

Always add `loading.tsx` and `error.tsx` alongside `page.tsx`:
```
app/
  projects/
    page.tsx
    loading.tsx   ← Suspense fallback shown automatically
    error.tsx     ← Error boundary shown automatically
```

## Layout Patterns

- Global providers go in `app/layout.tsx` (only once)
- Per-section layouts for auth, dashboard, etc.
- Never import client components in the root layout body — wrap in a client boundary

## cookies() in Next.js 15

`cookies()` is async in Next.js 15 — always `await` it:

```typescript
// ✅ Next.js 15
import { cookies } from 'next/headers'

export async function createClient() {
  const cookieStore = await cookies()
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { getAll() { return cookieStore.getAll() } } }
  )
}

// ❌ Next.js 14 style — causes build warning in 15
const cookieStore = cookies()
```

## Environment Variables

- `NEXT_PUBLIC_` prefix for anything the browser needs
- Server-only vars (no prefix) stay out of client bundles — Next.js throws if you access them client-side
- Add `.env.local` to `.gitignore` always
