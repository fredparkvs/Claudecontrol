---
name: python-patterns
description: Python best practices — project structure, type hints, error
  handling, async, CLI tools (Typer/Click), and packaging. Load for Python
  projects or when the user says "python".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Python Patterns

## Project Structure

```
src/
  your_package/
    __init__.py
    cli.py         ← Typer entrypoint
    core/          ← Business logic, no I/O
    agents/        ← LLM/agent orchestration
    models/        ← Pydantic models
    utils/         ← Pure helpers
tests/
pyproject.toml
```

## Type Hints — Always

```python
from typing import Optional
from pathlib import Path

def process_file(path: Path, encoding: str = "utf-8") -> Optional[str]:
    ...
```

Use `from __future__ import annotations` at the top of every file for forward refs.

## Error Handling

```python
# Define specific exceptions
class AgentError(Exception): ...
class RoutingError(AgentError): ...

# Use result types for recoverable errors (not bare strings)
from pydantic import BaseModel

class Result[T]:
    data: Optional[T]
    error: Optional[str]
```

Never bare-except. At minimum: `except Exception as e: logger.error(e); raise`

## Async Patterns

```python
import asyncio
from contextlib import asynccontextmanager

# Run concurrent tasks
results = await asyncio.gather(task1(), task2(), return_exceptions=True)

# Async context manager
@asynccontextmanager
async def managed_client():
    client = Client()
    try:
        yield client
    finally:
        await client.close()
```

## CLI with Typer

```python
import typer
app = typer.Typer()

@app.command()
def run(
    path: Path = typer.Argument(..., help="File to process"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
):
    """Process a file."""
    ...

if __name__ == "__main__":
    app()
```

## Pydantic Models

```python
from pydantic import BaseModel, Field, model_validator

class AgentConfig(BaseModel):
    model: str = Field(
        default="anthropic:claude-sonnet-4-6-20251022",
        description="LLM model ID"
    )
    max_steps: int = Field(default=10, ge=1, le=100)

    @model_validator(mode="after")
    def check_model(self) -> "AgentConfig":
        if not self.model.startswith(("anthropic:", "openai:", "google-")):
            raise ValueError("Unknown model provider")
        return self
```

## Packaging (pyproject.toml)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "your-package"
requires-python = ">=3.11"
dependencies = ["typer", "pydantic>=2", "httpx"]

[project.scripts]
your-cli = "your_package.cli:app"
```
