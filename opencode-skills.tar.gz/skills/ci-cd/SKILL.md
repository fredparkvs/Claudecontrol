---
name: ci-cd
description: GitHub Actions CI/CD for Next.js and Python projects — type-check,
  lint, test, build, and deploy on merge. Load when setting up CI, writing
  workflows, or the user asks about GitHub Actions.
---

> **Model**: `opencode/big-pickle`

# CI/CD with GitHub Actions

## Next.js Workflow

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm

      - run: npm ci

      - run: npm run type-check    # tsc --noEmit
      - run: npm run lint          # eslint
      - run: npm run test          # vitest run
      - run: npm run build
        env:
          NEXT_PUBLIC_SUPABASE_URL: ${{ secrets.NEXT_PUBLIC_SUPABASE_URL }}
          NEXT_PUBLIC_SUPABASE_ANON_KEY: ${{ secrets.NEXT_PUBLIC_SUPABASE_ANON_KEY }}
```

Add these scripts to `package.json`:
```json
{
  "scripts": {
    "type-check": "tsc --noEmit",
    "lint": "eslint . --max-warnings 0",
    "test": "vitest run"
  }
}
```

## Python Workflow

```yaml
# .github/workflows/python-ci.yml
name: Python CI

on: [push, pull_request]

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - run: pip install uv
      - run: uv sync --frozen

      - run: uv run ruff check .        # lint
      - run: uv run ruff format --check . # format
      - run: uv run mypy src/           # types
      - run: uv run pytest              # tests
```

## Supabase Migration Check

Catch migration drift before it reaches production:

```yaml
      - uses: supabase/setup-cli@v1
        with:
          version: latest

      - run: supabase db diff --schema public
        env:
          SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}
          SUPABASE_DB_PASSWORD: ${{ secrets.SUPABASE_DB_PASSWORD }}
```

## Secrets Management

- Store all secrets in **Settings → Secrets and variables → Actions**
- Never echo secrets: `echo $SECRET` leaks in logs
- Use environment-scoped secrets for staging vs production
- Reference with `${{ secrets.SECRET_NAME }}` — never hardcode

## Deploy on Merge to Main

```yaml
  deploy:
    needs: check
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v4
      - run: |
          docker buildx build --platform linux/amd64 -t $IMAGE_TAG .
          docker push $IMAGE_TAG
          ssh $VPS_HOST "docker compose pull && docker compose up -d"
        env:
          IMAGE_TAG: ${{ secrets.REGISTRY }}/app:${{ github.sha }}
          VPS_HOST: ${{ secrets.VPS_HOST }}
```
