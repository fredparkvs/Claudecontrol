---
name: supabase-patterns
description: Best practices for building with Supabase — RLS policies, Edge
  Functions, realtime, auth, and client patterns. Use when working on Supabase
  tables, policies, functions, or queries. Load when the user says "supabase".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Supabase Patterns

## RLS (Row Level Security)

ALWAYS enable RLS on every table. Every table needs explicit policies or it
blocks all access. Default template:

```sql
-- Enable RLS
ALTER TABLE public.your_table ENABLE ROW LEVEL SECURITY;

-- Allow user to read their own rows
CREATE POLICY "Users can view own rows"
  ON public.your_table FOR SELECT
  USING (auth.uid() = user_id);

-- Allow user to insert their own rows
CREATE POLICY "Users can insert own rows"
  ON public.your_table FOR INSERT
  WITH CHECK (auth.uid() = user_id);
```

## Client Setup (Next.js)

Use `@supabase/ssr` for server components and middleware:

```typescript
// lib/supabase/server.ts
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function createClient() {
  const cookieStore = await cookies()  // await required in Next.js 15
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { cookies: { getAll() { return cookieStore.getAll() } } }
  )
}
```

NEVER use the service role key in client-side or browser code.

## Query Patterns

- Select only columns you need: `.select('id, name, created_at')`
- Always handle errors: `const { data, error } = await ...`
- Use `.throwOnError()` only in server-side code where you have a try/catch
- For pagination: use `.range(from, to)` not `.limit()` alone
- Avoid N+1: fetch related data in one query with foreign table joins

## Edge Functions

```typescript
// supabase/functions/your-function/index.ts
import { serve } from 'https://deno.land/std/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js'

serve(async (req) => {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')! // OK server-side only
  )
  // ... logic
  return new Response(JSON.stringify({ ok: true }), {
    headers: { 'Content-Type': 'application/json' }
  })
})
```

## Free Tier Hygiene (important — user has multiple projects)

- Pause projects you're not actively using (Settings → Pause)
- Use `.select('count', { count: 'exact', head: true })` for counts
- Add database indexes on every foreign key and frequently filtered column
- Use Supabase's built-in auth instead of rolling your own — it's free

## Migrations

Always write migrations as SQL files in `supabase/migrations/`:
```
supabase migration new add_profiles_table
supabase db push          # local
supabase db push --linked # production
```
Never alter production schema directly in the dashboard.
