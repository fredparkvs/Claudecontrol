---
name: api-design
description: Design and review REST APIs and Next.js route handlers — naming,
  status codes, error shapes, auth, pagination, and versioning. Load when
  designing or reviewing API endpoints.
---

> **Model**: `opencode/claude-sonnet-4-6`

# API Design Patterns

## URL Naming

- Resources are plural nouns: `/api/projects`, `/api/users`
- Actions via HTTP verbs, not URLs: `DELETE /api/projects/123` not `/api/deleteProject`
- Nested resources for ownership: `/api/projects/123/members`
- Query params for filtering: `/api/projects?status=active&limit=20`

## Next.js Route Handler Pattern

```typescript
// app/api/projects/[id]/route.ts
import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .eq('id', params.id)
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 404 })
  return NextResponse.json(data)
}
```

## Error Response Shape

Always return the same error shape:
```json
{
  "error": "Human-readable message",
  "code": "MACHINE_READABLE_CODE",
  "details": {}
}
```

## Status Codes

| Situation | Code |
|---|---|
| Success, returns data | 200 |
| Created | 201 |
| Success, no body | 204 |
| Bad input from client | 400 |
| Not authenticated | 401 |
| Authenticated but no permission | 403 |
| Resource not found | 404 |
| Validation failed | 422 |
| Server error | 500 |

## Pagination

```typescript
// Cursor-based (preferred for large datasets)
const { data } = await supabase
  .from('projects')
  .select('*')
  .order('created_at', { ascending: false })
  .limit(20)
  .lt('created_at', cursor ?? new Date().toISOString())
```

Return: `{ data: [...], next_cursor: "...", has_more: true }`
