---
name: typescript-patterns
description: TypeScript best practices — strict mode, Zod validation, discriminated
  unions, type guards, and utility types. Load for any TypeScript or Next.js
  work, or when the user says "typescript" or "types".
---

> **Model**: `opencode/claude-sonnet-4-6`

# TypeScript Patterns

## Strict tsconfig

Always start with strict mode — it catches the bugs that matter:

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitReturns": true,
    "exactOptionalPropertyTypes": true
  }
}
```

## Zod — Runtime Validation at System Boundaries

Validate all external input (API bodies, env vars, form data) with Zod:

```typescript
import { z } from 'zod'

const CreateProjectSchema = z.object({
  name: z.string().min(1).max(100),
  status: z.enum(['active', 'archived']).default('active'),
})

type CreateProject = z.infer<typeof CreateProjectSchema>

// In a Next.js route handler
export async function POST(req: Request) {
  const body = await req.json()
  const result = CreateProjectSchema.safeParse(body)
  if (!result.success) {
    return Response.json({ error: result.error.flatten() }, { status: 422 })
  }
  // result.data is fully typed here
}
```

Validate env vars once at startup:

```typescript
// lib/env.ts
const EnvSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
})

export const env = EnvSchema.parse(process.env)
```

## Discriminated Unions

Use instead of optional fields and boolean flags:

```typescript
// ❌ confusing optional soup
type Result = {
  data?: Project
  error?: string
  loading?: boolean
}

// ✅ discriminated union — exactly one state at a time
type Result =
  | { status: 'loading' }
  | { status: 'success'; data: Project }
  | { status: 'error'; message: string }

// TypeScript narrows automatically in switch
switch (result.status) {
  case 'success': return result.data  // data is typed here
  case 'error':   return result.message
}
```

## Type Guards

```typescript
function isProject(value: unknown): value is Project {
  return (
    typeof value === 'object' &&
    value !== null &&
    'id' in value &&
    'name' in value
  )
}

// Assertion function (throws instead of returning boolean)
function assertProject(value: unknown): asserts value is Project {
  if (!isProject(value)) throw new TypeError('Expected a Project')
}
```

## Useful Utility Types

```typescript
// Pick only what you need
type ProjectSummary = Pick<Project, 'id' | 'name' | 'status'>

// Omit sensitive fields
type PublicUser = Omit<User, 'passwordHash' | 'serviceKey'>

// Make all fields optional for patch/update types
type UpdateProject = Partial<Pick<Project, 'name' | 'status'>>

// Extract return type without importing the type explicitly
type PageProps = Awaited<ReturnType<typeof getServerSideProps>>
```

## `satisfies` Operator

Validate shape without losing literal types:

```typescript
const config = {
  models: {
    intense: 'opencode/claude-sonnet-4-6',
    easy:    'opencode/big-pickle',
    plan:    'opencode/gpt-5',
  }
} satisfies { models: Record<string, string> }

// config.models.intense is still typed as the literal string, not just string
```

## Avoiding `any`

| Instead of | Use |
|---|---|
| `any` for unknown external data | `unknown` + type guard or Zod |
| `any` for flexible object | `Record<string, unknown>` |
| `any` for JSON | `Json` type from your DB client |
| `as any` to silence errors | Fix the underlying type mismatch |
