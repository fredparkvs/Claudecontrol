---
name: ai-agent-patterns
description: Patterns for building LLM-powered agents — orchestration, routing,
  tool use, PydanticAI, LiteLLM, prompt design, error recovery. Load when
  building AI agents, chatbots, or agentic CLI tools.
---

> **Model**: `opencode/claude-sonnet-4-6`

# AI Agent Patterns

## LiteLLM — Model-Agnostic Calls

```python
from litellm import completion

response = completion(
    model="anthropic/claude-sonnet-4-6-20251022",  # swap model without changing call site
    messages=[{"role": "user", "content": prompt}],
    temperature=0.0,
)
text = response.choices[0].message.content
```

Set `LITELLM_LOG=DEBUG` to see actual API calls during dev.

## PydanticAI — Typed Agent Outputs

```python
from pydantic_ai import Agent
from pydantic import BaseModel

class TaskResult(BaseModel):
    action: str
    confidence: float
    explanation: str

agent = Agent(
    "anthropic:claude-sonnet-4-6-20251022",
    result_type=TaskResult,
    system_prompt="You are a task router. Classify the user's intent.",
)

result = await agent.run("Deploy the app to staging")
print(result.data.action)   # "deploy"
```

## Routing Pattern

Use a cheap/fast model for routing — classification does not need a powerful model:

```python
ROUTES = {
    "edit": edit_agent,
    "explore": explore_agent,
    "plan": plan_agent,
}

router_agent = Agent(
    "anthropic:claude-haiku-4-5-20251001",  # fast + cheap for routing only
    result_type=RouteDecision,
    system_prompt="Classify the user's intent into one of: edit, explore, plan.",
)

async def route(user_input: str) -> str:
    intent = await router_agent.run(user_input)
    agent = ROUTES.get(intent.data.action, edit_agent)
    return await agent.run(user_input)
```

## Tool Use (Function Calling)

```python
from pydantic_ai import Agent, RunContext

@agent.tool
async def read_file(ctx: RunContext, path: str) -> str:
    """Read a file and return its contents."""
    return Path(path).read_text()

@agent.tool
async def run_command(ctx: RunContext, cmd: str) -> str:
    """Run a shell command and return stdout."""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout + result.stderr
```

## Prompt Engineering Rules

1. **System prompt**: persona + constraints + output format
2. **User turn**: task + context (inject files/code here)
3. **Temperature**: 0.0 for routing/extraction, 0.3–0.7 for generation
4. Keep system prompts under 500 tokens — beyond that, use skills/tools
5. Put constraints at the END of the system prompt (recency bias)

## Error Recovery

```python
MAX_RETRIES = 3

async def resilient_call(prompt: str) -> str:
    for attempt in range(MAX_RETRIES):
        try:
            return await agent.run(prompt)
        except RateLimitError:
            await asyncio.sleep(2 ** attempt)
        except ContextLengthError:
            prompt = truncate_prompt(prompt)
    raise AgentError("Max retries exceeded")
```

## Context Window Management

- Summarize old turns before they hit 80% of context limit
- Store tool outputs in a structured `MemoryStore`, not raw in the message history
- Use `maxSteps` limits to prevent infinite loops in agentic flows
