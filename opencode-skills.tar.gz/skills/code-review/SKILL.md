---
name: code-review
description: Reviews code for bugs, security issues, and quality. Use when
  the user asks for a code review, PR review, "check this code", or "audit this".
---

> **Model**: `opencode/claude-sonnet-4-6`

# Code Review

When asked to review code:

1. Identify files to review — check `git diff` or ask the user
2. Read each file completely before commenting

## Review Layers

### 🔴 Critical (block merge)
- SQL injection via string concatenation
- XSS from unescaped user input
- Auth/authz bypasses
- Hardcoded secrets or API keys
- Exposed Supabase service role key on client
- Unhandled errors that expose stack traces in production

### 🟡 Warning (should fix)
- N+1 database queries (especially Supabase `.select()` in loops)
- Race conditions in async code
- Missing input validation on API routes
- React state mutations
- Missing RLS policies on new Supabase tables
- Memory leaks (uncleared intervals, unclosed streams)

### 🔵 Suggestion (consider fixing)
- Functions longer than 40 lines
- 3+ levels of nesting — suggest early returns
- Missing error boundaries in React
- Duplicate logic that could be a utility
- Type `any` used without justification

## Output Format

Group by severity. For each finding:
- File and approximate line
- What the issue is
- Why it matters
- Concrete fix with code snippet

If no issues found, explicitly say so.
